#!/bin/bash

# return 1 if global command line program installed, else 0
function program_is_installed {
  # set to 1 initially
  local return_=1
  # set to 0 if not found
  type $1 >/dev/null 2>&1 || { local return_=0; }
  # return value
  echo "$return_"
}

# function npm_package_is_installed {
#   # set to 1 initially
#   local return_=1
#   # set to 0 if not found
#   ls node_modules | grep $1 >/dev/null 2>&1 || { local return_=0; }
#   # return value
#   echo "$return_"
# }

# cd /home/ec2-user

# sudo yum update -y

# # Check if Node.js is installed. If not, install it with nvm
# if [ $(program_is_installed node) == 1 ]; then
#   echo "Node is installed"
# else
#   echo "Installing NodeJS"
#   sudo curl --silent --location https://rpm.nodesource.com/setup_current.x | sudo bash -
#   sudo yum -y install nodejs
#   sudo npm install -g npm
#   sudo npm install -g npm-check-updates
# fi

# # Check if Git is installed
# if [ $(program_is_installed git) == 1 ]; then
#   echo "Git is installed"
# else
#   sudo yum install git -y
# fi

# # Check if Docker is installed
# if [ $(program_is_installed docker) == 1 ]; then
#   echo "Docker is installed"
# else
#   # (for amazon linux 2)
#   sudo amazon-linux-extras install docker -y
#   # start docker service
#   sudo systemctl start docker
#   # start docker redis server in detach mode
#   sudo docker run --name chatapp-redis -p 6379:6379 --restart always --detach redis
# fi

# # Check if redis-commander is installed
# if [ $(program_is_installed redis-commander) == 1 ]; then
#   echo "redis-commander is installed"
# else
#   sudo npm install -g redis-commander
#   nohup redis-commander &
# fi

# # Check if redis-commander is installed
# if [ $(program_is_installed pm2) == 1 ]; then
#   echo "pm2 is installed"
# else
#   sudo npm install -g pm2
# fi

# DIR="/home/ec2-user/angular-chatapp-server"
# if [ -d "$DIR" ]; then
#   echo "Directory in the specified path ${DIR} already exists."
#   cd angular-chatapp-server
#   git pull origin master # find a way to make the branch name dynamic
#   sudo npm install
#   # find a way to add to .env if there is a new variable
#   sudo npm run build
# else
#   echo "Directory does not exists"
#   git clone https://github.com/uzoeddie/angular-chatapp-server.git
#   cd angular-chatapp-server
#   sudo npm install
#   sudo touch .env
#   JWT_TOKEN=JWT_TOKEN=thisisajwttoken
#   CLOUD_NAME=CLOUD_NAME=ratingapp
#   CLOUD_API_KEY=CLOUD_API_KEY=876293337577449
#   CLOUD_API_SECRET=CLOUD_API_SECRET=-2arHr9Apmm3SbFSRnsD0d7mE4g
#   NEW_RELIC_KEY=NEW_RELIC_KEY=eu01xx4aa8abc7ef7a502b109f44460afcb0NRAL
#   SENDER_EMAIL=SENDER_EMAIL=uzo.odozi@gmail.com
#   SENDER_EMAIL_PASSWORD=SENDER_EMAIL_PASSWORD=happiness1
#   TESTING_RECEIVER_EMAIL=TESTING_RECEIVER_EMAIL=uzo.odozi@gmail.com
#   CLIENT_URL=CLIENT_URL=http://localhost:4200
#   REDIS_HOST=REDIS_HOST='localhost'
#   LOG_LEVEL=LOG_LEVEL=info
#   NODE_ENV=NODE_ENV=production
#   SECRET_KEY_ONE=SECRET_KEY_ONE=thisiscookiesecret
#   SECRET_KEY_TWO=SECRET_KEY_TWO=thisisanothercookiesecret
#   DATABASE_URL=DATABASE_URL="mongodb+srv://admin:adminuser@chatapp.cimi0.mongodb.net/chatapp-backend?retryWrites=true&w=majority"

#   cat <<EOF >> /home/ec2-user/angular-chatapp-server/.env
# $JWT_TOKEN
# $CLOUD_NAME
# $CLOUD_API_KEY
# $NEW_RELIC_KEY
# $SENDER_EMAIL
# $SENDER_EMAIL_PASSWORD
# $TESTING_RECEIVER_EMAIL
# $CLIENT_URL
# $REDIS_HOST
# $LOG_LEVEL
# $NODE_ENV
# $SECRET_KEY_ONE
# $SECRET_KEY_TWO
# $DATABASE_URL
# EOF
#   sudo npm run build
#   sudo npm start
# fi
